package ru.ifmo.optimization.instance;

public interface Hashable {
	Long computeStringHash();
}
