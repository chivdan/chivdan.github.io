package ru.ifmo.ctddev.genetic.transducer.scenario;

public class Vertex {
	final String event;
	
	Vertex(String event) {
		this.event = event;
	}
	
}
