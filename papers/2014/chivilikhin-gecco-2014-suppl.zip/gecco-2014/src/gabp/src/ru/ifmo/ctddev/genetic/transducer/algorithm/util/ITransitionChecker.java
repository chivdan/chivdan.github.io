/* 
 * Developed by eVelopers Corporation, 2010
 */
package ru.ifmo.ctddev.genetic.transducer.algorithm.util;

import ru.ifmo.ctddev.genetic.transducer.algorithm.Transition;

/**
 * @author kegorov
 *         Date: May 6, 2010
 */
public interface ITransitionChecker {

    boolean isMarked(Transition t);
}
