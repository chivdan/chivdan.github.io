#!/bin/bash
java -jar -Xms2g -Xmx2g muaco.jar > log.log 2>errlog.log
